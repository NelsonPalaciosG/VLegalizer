﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VLegalizer.Common.Enums
{
    public enum UserType
    {
        Admin,
        Employee
    }
}
