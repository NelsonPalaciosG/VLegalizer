﻿using Xamarin.Forms;

namespace VLegalizer.Prism.Views
{
    public partial class AddTripPage : ContentPage
    {
        public AddTripPage()
        {
            InitializeComponent();
        }
    }
}
