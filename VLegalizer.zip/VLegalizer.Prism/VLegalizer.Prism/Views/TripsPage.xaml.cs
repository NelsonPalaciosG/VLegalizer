﻿using Xamarin.Forms;

namespace VLegalizer.Prism.Views
{
    public partial class TripsPage : ContentPage
    {
        public TripsPage()
        {
            InitializeComponent();
        }
    }
}
