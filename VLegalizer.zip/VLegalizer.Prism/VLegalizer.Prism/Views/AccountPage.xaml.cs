﻿using Xamarin.Forms;

namespace VLegalizer.Prism.Views
{
    public partial class AccountPage : ContentPage
    {
        public AccountPage()
        {
            InitializeComponent();
        }
    }
}
