﻿using Xamarin.Forms;

namespace VLegalizer.Prism.Views
{
    public partial class LoginPage : ContentPage
    {
        public LoginPage()
        {
            InitializeComponent();
        }
    }
}
