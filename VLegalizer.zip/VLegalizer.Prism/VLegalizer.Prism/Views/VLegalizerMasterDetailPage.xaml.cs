﻿using Xamarin.Forms;

namespace VLegalizer.Prism.Views
{
    public partial class VLegalizerMasterDetailPage : MasterDetailPage
    {
        public VLegalizerMasterDetailPage()
        {
            InitializeComponent();
        }
    }
}