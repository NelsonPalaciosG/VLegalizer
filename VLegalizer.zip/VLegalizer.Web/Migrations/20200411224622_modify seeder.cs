﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace VLegalizer.Web.Migrations
{
    public partial class modifyseeder : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
